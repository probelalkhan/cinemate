package dev.belalkhan.cinemate

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dev.belalkhan.cinemate.data.remote.CinemateHttpClientBuilder
import io.ktor.client.HttpClient
import io.ktor.http.URLProtocol

@InstallIn(SingletonComponent::class)
@Module
object AppModule {

    @Provides
    fun providesHttpClient(builder: CinemateHttpClientBuilder): HttpClient = builder
        .protocol(URLProtocol.HTTPS)
        .host("api.themoviedb.org/3")
        .authToken(BuildConfig.AUTH_TOKEN)
        .build()
}
