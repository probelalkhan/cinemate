package dev.belalkhan.cinemate

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CinemateApp : Application()
